const NET_FOLDERS = {
  main: 'main',
  test: 'test'
}
const NODES = {
  main: 'https://sync-mainnet.vechain.org',
  test: 'https://sync-testnet.vechain.org'
}

module.exports = {
  NETS: NET_FOLDERS,
  NODES
}
